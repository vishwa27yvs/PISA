
To run PreActResNet18, Input Mixup, Manifold mixup and PuzzleMix : cd into the Eucledian directory 


```
cd Eucledian
```
To run PISA: cd into the Hyperbolic directory

```
cd Hyperbolic
```
